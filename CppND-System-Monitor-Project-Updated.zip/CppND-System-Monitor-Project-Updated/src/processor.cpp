#include "processor.h"
#include "linux_parser.h"
#include <unistd.h>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() 
{
    long first_Jiffies = LinuxParser::Jiffies();
    long first_ActJiffies = LinuxParser::ActiveJiffies();
    sleep(1); // difference in duration of reading can be adjusted later
    long second_Jiffies = LinuxParser::Jiffies();
    long second_ActJiffies = LinuxParser::ActiveJiffies();

    float delta_Jiffies = (float)second_Jiffies - (float)first_Jiffies;
    float delta_ActJiffies = (float)second_ActJiffies - (float)first_ActJiffies;

    
    return (delta_ActJiffies/delta_Jiffies); 
}